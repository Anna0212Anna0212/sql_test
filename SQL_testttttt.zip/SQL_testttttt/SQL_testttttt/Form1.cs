﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;


namespace SQL_testttttt
{
    public partial class Form1 : Form
    {
        Database1Entities db = new Database1Entities();
        string JsonString;
        bool is_open = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (is_open && !string.IsNullOrEmpty(JsonString))
            {
                try
                {
                    List<Travel> JsonData = JsonSerializer.Deserialize<List<Travel>>(JsonString);  //json反序列化

                    int ID = 0; //設定ID數字
                    foreach (Travel Table in JsonData)  //將json檔存入
                    {
                        Table.Id = ID++;  //加入ID
                        db.Travel.Add(Table);  //加入資料
                    }
                    db.Travel.AddRange(JsonData);
                    db.SaveChanges();  //檔案更新

                    DataTable dt = new DataTable();  //建立 DataTable in dataGridView1
                    dt.Columns.Add("name");
                    dt.Columns.Add("about");
                    dt.Columns.Add("address");
                    dt.Columns.Add("traffic");
                    dt.Columns.Add("time");

                    foreach (var table in db.Travel)  //LINQ塞選方式加入資料到dataGridView1
                    {
                        dt.Rows.Add(table.name, table.about, table.address, table.traffic, table.time);
                    }

                    // 將 DataTable 設定為 DataGridView 的資料來源
                    dataGridView1.DataSource = dt;

                    MessageBox.Show("成功");
                }
                catch
                {
                    MessageBox.Show("失敗!");
                }
            }
        }

        private void toolStripButton1_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "JSON File|*.json";

            try
            {
                if (open.ShowDialog() == DialogResult.OK)
                {
                    JsonString = File.ReadAllText(open.FileName);
                    MessageBox.Show("匯入成功!");
                    is_open = true;
                    Form1_Load(sender, e);
                }
            }
            catch 
            {
                MessageBox.Show("匯入失敗");
            }
        }

        private void sreach_Click(object sender, EventArgs e)
        {

        }

        private void no_sreach_Click(object sender, EventArgs e)
        {
            
        }
    }
}
