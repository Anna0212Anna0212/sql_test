using Microsoft.Data.SqlClient;
using System.Data;

namespace SQL_Form
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection();
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
