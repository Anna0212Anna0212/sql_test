﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace sql_test2
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        static string connectionString = "Server=ANNA\\SQLEXPRESS;Database=test3;Trusted_Connection=True;";

        private void Form1_Load(object sender, EventArgs e)
        {
        }
        private void button3_Click(object sender, EventArgs e)
        {
            string SELECT = "SELECT [Id], [User], [Password] FROM [dbo].[Table_1];";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand comm = new SqlCommand(SELECT, conn);
                conn.Open();
                using (SqlDataReader reader = comm.ExecuteReader())
                {
                    dataGridView1.Rows.Clear();
                    while (reader.Read())
                    {
                        if ((reader["Id"]).ToString() == textBox1.Text || (reader["User"]).ToString() == textBox2.Text || (reader["Password"]).ToString() == textBox3.Text)
                        {
                            dataGridView1.Rows.Add(reader["Id"], reader["User"], reader["Password"]);
                        }
                    }
                }
            }
        }
        static string DELETE;
        private void button2_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox1.Text))
            {
                DELETE = "DELETE FROM [dbo].[Table_1] WHERE [Id] = @Id AND [User] = (SELECT [User] FROM [dbo].[Table_1] WHERE [Id] = @Id)  AND [Password] = (SELECT [Password] FROM [dbo].[Table_1] WHERE [Id] = @Id) ";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    SqlCommand comm = new SqlCommand(DELETE, conn);
                    comm.Parameters.AddWithValue("Id", int.Parse(textBox1.Text));
                    conn.Open();
                    comm.ExecuteNonQuery();
                    button5_Click(sender, e);
                }
            }
            if (!string.IsNullOrWhiteSpace(textBox2.Text))
            {
                DELETE = "DELETE FROM [dbo].[Table_1] WHERE [User] = @User AND [Id] = (SELECT [Id] FROM [dbo].[Table_1] WHERE [User] = @User)  AND [Password] = (SELECT [Password] FROM [dbo].[Table_1] WHERE [User] = @User) ";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    SqlCommand comm = new SqlCommand(DELETE, conn);
                    comm.Parameters.AddWithValue("User", textBox2.Text);
                    conn.Open();
                    comm.ExecuteNonQuery();
                    button5_Click(sender, e);
                }
            }
            if (!string.IsNullOrWhiteSpace(textBox3.Text))
            {
                DELETE = "DELETE FROM [dbo].[Table_1] WHERE [Password] = @Password AND [User] = (SELECT [User] FROM [dbo].[Table_1] WHERE [Password] = @Password)  AND [Id] = (SELECT [Id] FROM [dbo].[Table_1] WHERE [Password] = @Password) ";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    SqlCommand comm = new SqlCommand(DELETE, conn);
                    comm.Parameters.AddWithValue("Password", textBox3.Text);
                    conn.Open();
                    comm.ExecuteNonQuery();
                    button5_Click(sender, e);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox1.Text) && !string.IsNullOrWhiteSpace(textBox2.Text))
            {
                string query = "UPDATE [dbo].[Table_1] SET [User] = @User WHERE [Id] = @Id";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@User", textBox2.Text);
                    cmd.Parameters.AddWithValue("@Id", int.Parse(textBox1.Text));

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    button5_Click(sender, e);
                }
            }
            if (!string.IsNullOrWhiteSpace(textBox1.Text) && !string.IsNullOrWhiteSpace(textBox3.Text))
            {
                string query = "UPDATE [dbo].[Table_1] SET [Password] = @Password WHERE [Id] = @Id";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Password", textBox3.Text);
                    cmd.Parameters.AddWithValue("@Id", textBox1.Text);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    button5_Click(sender, e);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string INSERT = "INSERT INTO [dbo].[Table_1]([Id],[User],[Password]) VALUES(@Id,@User,@Password)";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand comm = new SqlCommand(INSERT, conn);
                comm.Parameters.AddWithValue("Id", int.Parse(textBox1.Text));
                comm.Parameters.AddWithValue("User", textBox2.Text);
                comm.Parameters.AddWithValue("Password", textBox3.Text);
                conn.Open();
                comm.ExecuteNonQuery();  
                dataGridView1.Rows.Add(textBox1.Text, textBox2.Text, textBox3.Text);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string SELECT = "SELECT [Id],[User],[Password] FROM [dbo].[Table_1]";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand comm = new SqlCommand(SELECT, conn);
                conn.Open();
                using (SqlDataReader reader = comm.ExecuteReader())
                {
                    dataGridView1.Rows.Clear();
                    while (reader.Read())
                    {
                        dataGridView1.Rows.Add(reader["Id"], reader["User"], reader["Password"]);
                    }
                }
            }
        }
    }
}
